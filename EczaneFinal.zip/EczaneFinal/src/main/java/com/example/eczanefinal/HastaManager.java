package com.example.eczanefinal;

import java.util.ArrayList;

public class HastaManager {
    private ArrayList<Hastalar> hastalarListesi = new ArrayList<>();

    public void hastaEkle(Hastalar hasta) {
        hastalarListesi.add(hasta);
    }

    public ArrayList<Hastalar> getHastalarListesi() {
        return hastalarListesi;
    }
}
