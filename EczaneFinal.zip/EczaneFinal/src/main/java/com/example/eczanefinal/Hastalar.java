package com.example.eczanefinal;

import java.util.ArrayList;

public class Hastalar {
    private int id;
    private String ad;
    private String soyad;
    private String sikayet;
    private ArrayList<Ilaclar> ilacListesi;

    public Hastalar(int id, String ad, String soyad, String sikayet) {
        this.id = id;
        this.ad = ad;
        this.soyad = soyad;
        this.sikayet = sikayet;
        this.ilacListesi = new ArrayList<>();
    }

    // Getter ve Setter metodları
    public int getId() {
        return id;
    }

    public String getAd() {
        return ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public String getSikayet() {
        return sikayet;
    }

    public void ilacEkle(Ilaclar ilac) {
        this.ilacListesi.add(ilac);
    }

    public ArrayList<Ilaclar> getIlacListesi() {
        return ilacListesi;
    }

    @Override
    public String toString() {
        return ("ID: " + id + ", Ad: " + ad + ", Soyad: " + soyad + ", Şikayet: " + sikayet);
    }
}
