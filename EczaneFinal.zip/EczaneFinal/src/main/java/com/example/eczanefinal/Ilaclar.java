package com.example.eczanefinal;

public class Ilaclar {
    private String ad;
    private int dozaj;

    public Ilaclar(String ad, int dozaj) {
        this.ad = ad;
        this.dozaj = dozaj;
    }

    @Override
    public String toString() {
        return ("Ilac Adı: "+ad + "         Dozaj: " + dozaj);
    }
}
