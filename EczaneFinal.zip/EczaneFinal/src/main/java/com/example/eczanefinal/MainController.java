package com.example.eczanefinal;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class MainController {

    @FXML
    private TextField hastaAdiField;

    @FXML
    private TextField hastaSoyadiField;

    @FXML
    private TextField sikayetField;

    @FXML
    private ListView<String> hastalarListView;

    @FXML
    private ListView<String> detayListView;

    private HastaManager hastaManager = new HastaManager();
    private Hastalar mevcutHasta;

    @FXML
    public void initialize() {
        hastalarListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                int selectedIndex = hastalarListView.getSelectionModel().getSelectedIndex();
                mevcutHasta = hastaManager.getHastalarListesi().get(selectedIndex);
                detaylariGoster();
            }
        });
    }

    @FXML
    public void hastaEkle() {
        String ad = hastaAdiField.getText();
        String soyad = hastaSoyadiField.getText();
        String sikayet = sikayetField.getText();

        if (ad.isEmpty() || soyad.isEmpty() || sikayet.isEmpty()) {
            showAlert("Hata", "Tüm alanları doldurun!", "Lütfen hasta adı, soyadı ve şikayetini girin.");
            return;
        }

        // Yeni hasta oluşturuluyor
        int id = hastaManager.getHastalarListesi().size() + 1;
        mevcutHasta = new Hastalar(id, ad, soyad, sikayet);
        hastaManager.hastaEkle(mevcutHasta);

        // Hastalar listesine ekleme
        hastalarListView.getItems().clear();  // Listeyi temizle
        for (Hastalar hasta : hastaManager.getHastalarListesi()) {
            hastalarListView.getItems().add("Hasta: " + hasta.getAd() + " " + hasta.getSoyad());
        }

        detayListView.getItems().clear(); // Detayları temizle
        ilacEkle();

        // Formu temizle
        hastaAdiField.clear();
        hastaSoyadiField.clear();
        sikayetField.clear();
    }

    private void detaylariGoster() {
        detayListView.getItems().clear();
        if (mevcutHasta != null) {
            detayListView.getItems().add("                      Hasta Bilgileri");
            detayListView.getItems().add("Hasta Adı: " + mevcutHasta.getAd());
            detayListView.getItems().add("Hasta Soyadı: " + mevcutHasta.getSoyad());
            detayListView.getItems().add("Şikayet: " + mevcutHasta.getSikayet());
            detayListView.getItems().add("                            İlaçlar");
            for (Ilaclar ilac : mevcutHasta.getIlacListesi()) {
                detayListView.getItems().add(" * " + ilac.toString());
            }
        }
    }

    private void ilacEkle() {
        int ilacSayisi = 0;
        try {
            String ilacSayisiStr = showInputDialog("Kaç ilaç gireceksiniz?");
            ilacSayisi = Integer.parseInt(ilacSayisiStr);
        } catch (NumberFormatException e) {
            showAlert("Hata", "Geçersiz sayı!", "Lütfen geçerli bir sayı girin.");
            return;
        }

        // İlacın her birini ekle
        for (int i = 0; i < ilacSayisi; i++) {
            Ilaclar ilac = UIHelper.showIlacEkleDialog();  // İlac ekleme diyalogu
            if (ilac != null) {
                mevcutHasta.ilacEkle(ilac);
            }
        }

        detaylariGoster();  // Detayları güncelle
    }

    private String showInputDialog(String message) {
        TextField inputField = new TextField();
        inputField.setPromptText(message);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Ilac Bilgileri");
        alert.getDialogPane().setContent(inputField);
        alert.showAndWait();

        return inputField.getText();
    }

    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
