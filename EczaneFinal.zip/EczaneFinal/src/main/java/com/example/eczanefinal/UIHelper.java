package com.example.eczanefinal;

import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class UIHelper {
    public static void showInfoDialog(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static Ilaclar showIlacEkleDialog() {
        Dialog<Ilaclar> dialog = new Dialog<>();
        dialog.setTitle("İlaç Ekle");
        dialog.setHeaderText("Yeni ilaç bilgilerini giriniz.");

        // Butonlar ekleme
        ButtonType tamamButton = new ButtonType("Tamam", ButtonBar.ButtonData.OK_DONE);
        ButtonType iptalButton = new ButtonType("İptal", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(tamamButton, iptalButton);

        TextField ilacAdiField = new TextField();
        ilacAdiField.setPromptText("İlaç Adı");

        TextField dozajField = new TextField();
        dozajField.setPromptText("Dozaj");

        VBox vbox = new VBox(10, ilacAdiField, dozajField);
        dialog.getDialogPane().setContent(vbox);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == tamamButton) {
                try {
                    return new Ilaclar(ilacAdiField.getText(), Integer.parseInt(dozajField.getText()));
                } catch (NumberFormatException e) {
                    showInfoDialog("Hata", "Geçersiz Dozaj", "Dozaj sayısal bir değer olmalıdır.");
                    return null;
                }
            }
            return null;
        });

        return dialog.showAndWait().orElse(null);
    }
}
